import 'package:flutter/material.dart';

void main() => runApp(const NutriAIApp());

class NutriAIApp extends StatelessWidget {
  const NutriAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NutriAI',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7F9F7),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int kcal = 1280;
  int protein = 86;
  int carbs = 142;
  int fat = 38;
  int selected = 0;

  void addMeal() {
    setState(() {
      kcal += 420;
      protein += 30;
      carbs += 45;
      fat += 12;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Refeição adicionada — análise simulada.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NutriAI', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.person_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: selected,
          children: [
            _dashboard(),
            _diary(),
            _progress(),
          ],
        ),
      ),
      floatingActionButton: selected == 0
          ? FloatingActionButton.extended(
              onPressed: addMeal,
              icon: const Icon(Icons.camera_alt_outlined),
              label: const Text('Registrar refeição'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), label: 'Diário'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Progresso'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    const goal = 2400;
    final progress = kcal / goal;
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
      children: [
        Text('Sexta-feira, 3 de outubro',
            style: TextStyle(color: Colors.grey.shade700)),
        const SizedBox(height: 12),
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Calorias de hoje',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Text('$kcal kcal',
                    style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900)),
                Text('de $goal kcal',
                    style: TextStyle(color: Colors.grey.shade600)),
                const SizedBox(height: 14),
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: LinearProgressIndicator(
                    minHeight: 12,
                    value: progress.clamp(0, 1),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            _macroCard('Proteína', '${protein}g', Icons.fitness_center),
            _macroCard('Carboidrato', '${carbs}g', Icons.grain),
            _macroCard('Gordura', '${fat}g', Icons.opacity),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Refeições',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        _meal('☕', 'Café da manhã', 'Ovos, pão e café', '420 kcal'),
        _meal('🍛', 'Almoço', 'Arroz, feijão, frango e salada', '650 kcal'),
        _meal('🍌', 'Lanche', 'Banana e iogurte', '210 kcal'),
        const SizedBox(height: 16),
        Card(
          elevation: 0,
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.auto_awesome)),
            title: const Text('Análise por IA'),
            subtitle: const Text(
                'Tire uma foto do prato e o NutriAI poderá identificar os alimentos.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: addMeal,
          ),
        ),
      ],
    );
  }

  Widget _macroCard(String title, String value, IconData icon) {
    return Expanded(
      child: Card(
        elevation: 0,
        margin: const EdgeInsets.symmetric(horizontal: 3),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 7),
          child: Column(
            children: [
              Icon(icon, size: 20),
              const SizedBox(height: 5),
              Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(title, style: const TextStyle(fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _meal(String emoji, String title, String desc, String calories) {
    return Card(
      elevation: 0,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.white,
          child: Text(emoji, style: const TextStyle(fontSize: 22)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(desc),
        trailing: Text(calories,
            style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
    );
  }

  Widget _diary() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Diário alimentar',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text('Tudo o que você registrou hoje.',
            style: TextStyle(color: Colors.grey.shade700)),
        const SizedBox(height: 20),
        _meal('☕', 'Café da manhã', 'Ovos, pão e café', '420 kcal'),
        _meal('🍛', 'Almoço', 'Arroz, feijão, frango e salada', '650 kcal'),
        _meal('🍌', 'Lanche', 'Banana e iogurte', '210 kcal'),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: addMeal,
          icon: const Icon(Icons.add),
          label: const Text('Adicionar refeição'),
        ),
      ],
    );
  }

  Widget _progress() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Progresso',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: const [
                Icon(Icons.trending_up, size: 45),
                SizedBox(height: 10),
                Text('Meta atual', style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 4),
                Text('Ganhar massa muscular',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                SizedBox(height: 14),
                Text('2.400 kcal / dia • 150 g proteína'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
