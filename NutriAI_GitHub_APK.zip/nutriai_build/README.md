# NutriAI — MVP

Primeira versão de um app de diário alimentar inspirado em aplicativos de nutrição por foto.

## Rodar
1. Instale o Flutter.
2. Abra esta pasta no VS Code ou Android Studio.
3. Execute `flutter pub get`.
4. Execute `flutter run`.

## Próxima etapa
Trocar a análise simulada por câmera + IA, adicionar cadastro de alimentos, perfil, metas, banco de dados e histórico.
