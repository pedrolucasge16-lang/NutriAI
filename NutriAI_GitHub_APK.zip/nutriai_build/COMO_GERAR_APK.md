# NutriAI — gerar APK pelo GitHub

Este projeto já contém um workflow para compilar o APK na nuvem.

1. Crie um repositório novo no GitHub chamado `NutriAI`.
2. Envie todos os arquivos deste projeto para o repositório.
3. Entre na aba **Actions**.
4. Abra **Build NutriAI APK**.
5. Toque em **Run workflow** (se necessário) ou faça um novo push na branch `main`.
6. Quando terminar, abra a execução concluída e procure **Artifacts** → `NutriAI-APK`.
7. Baixe o ZIP do artifact, extraia e instale o `app-release.apk` no Android.

O workflow usa Flutter estável e Java 17 e cria automaticamente a estrutura Android antes da compilação.
